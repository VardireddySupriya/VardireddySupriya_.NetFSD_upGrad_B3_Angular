const container = document.getElementById("cart-items");

let cart = JSON.parse(localStorage.getItem("cart")) || [];

//  Render Cart Function
function renderCart() {

  if (cart.length === 0) {
    container.innerHTML = "<h4>Cart is empty</h4>";
    return;
  }

  let output = `
    <table class="table table-bordered text-center align-middle">
      <thead class="table-dark">
        <tr>
          <th>Image</th>
          <th>Name</th>
          <th>Price</th>
          <th>Size</th>
          <th>Quantity</th>
          <th>Total</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
  `;

  let grandTotal = 0;

  cart.forEach((item, index) => {
    let total = item.price * item.quantity;
    grandTotal += total;

    output += `
      <tr>
        <td><img src="${item.image}" width="70"></td>
        <td>${item.name}</td>
        <td>₹${item.price}</td>
        <td>${item.size}</td>

        <td>
          <button onclick="decreaseQty(${index})" class="btn btn-sm btn-danger">-</button>
          <span class="mx-2">${item.quantity}</span>
          <button onclick="increaseQty(${index})" class="btn btn-sm btn-success">+</button>
        </td>

        <td>₹${total}</td>

        <td>
          <button onclick="removeItem(${index})" class="btn btn-sm btn-dark">
            Remove
          </button>
        </td>
      </tr>
    `;
  });

  output += `
      </tbody>
    </table>

    <h4 class="text-end">Grand Total: ₹${grandTotal}</h4>

    <div class="text-end">
      <!-- FIXED BUTTON -->
      <button onclick="proceedToBuy()" class="btn btn-primary">
        Proceed to Buy
      </button>
    </div>
  `;

  container.innerHTML = output;
}

// Increase Quantity
function increaseQty(index) {
  cart[index].quantity += 1;
  updateCart();
}

//  Decrease Quantity
function decreaseQty(index) {
  if (cart[index].quantity > 1) {
    cart[index].quantity -= 1;
  } else {
    removeItem(index);
    return;
  }
  updateCart();
}

//  Remove Item
function removeItem(index) {
  cart.splice(index, 1);
  updateCart();
}

//  Update Cart
function updateCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

//  NEW: PROCEED TO BUY FUNCTION
function proceedToBuy() {

  if (cart.length === 0) {
    alert("Cart is empty!");
    return;
  }

  let buy = JSON.parse(localStorage.getItem("buy")) || [];

  //  Merge cart → buy (no duplicates)
  cart.forEach(item => {
    const existing = buy.find(p =>
      p.id === item.id && p.size === item.size
    );

    if (existing) {
      existing.quantity += item.quantity;
    } else {
      buy.push(item);
    }
  });

  localStorage.setItem("buy", JSON.stringify(buy));

  //  clear cart after moving
  localStorage.removeItem("cart");

  window.location.href = "buy.html";
}

//  Initial Load
renderCart();
const table = document.getElementById("buy-table");
const totalEl = document.getElementById("grand-total");

//  CHANGE: use BUY instead of cart
let buy = JSON.parse(localStorage.getItem("buy")) || [];

function renderBuy() {

  if (buy.length === 0) {
    table.innerHTML = "<tr><td colspan='8'>No items to buy</td></tr>";
    totalEl.innerText = "";
    return;
  }

  let output = "";
  let grandTotal = 0;

  buy.forEach((item, index) => {

    let total = item.price * item.quantity;
    grandTotal += total;

    output += `
      <tr>

        <!-- IMAGE -->
        <td>
          <img src="${item.image}" 
               style="width:80px; height:80px; object-fit:cover; border-radius:8px;">
        </td>

        <!-- NAME -->
        <td>${item.name}</td>

        <!-- PRICE -->
        <td>₹${item.price}</td>

        <!-- SIZE -->
        <td>${item.size}</td>

        <!-- QUANTITY -->
        <td>
          <button onclick="decreaseQty(${index})" class="btn btn-sm btn-danger">-</button>
          <span class="mx-2 fw-bold">${item.quantity}</span>
          <button onclick="increaseQty(${index})" class="btn btn-sm btn-success">+</button>
        </td>

        <!-- TOTAL -->
        <td class="fw-bold text-success">₹${total}</td>

        <!-- 🛒 ADD TO CART BUTTON -->
        <td>
          <button onclick="addToCart(${index})" class="btn btn-sm btn-warning">
            Add to Cart
          </button>
        </td>

        <!-- REMOVE -->
        <td>
          <button onclick="removeItem(${index})" class="btn btn-sm btn-dark">
            Remove
          </button>
        </td>

      </tr>
    `;
  });

  table.innerHTML = output;
  totalEl.innerText = "Grand Total: ₹" + grandTotal;
}

//  Increase Quantity
function increaseQty(index) {
  buy[index].quantity++;
  updateBuy();
}

//  Decrease Quantity
function decreaseQty(index) {
  if (buy[index].quantity > 1) {
    buy[index].quantity--;
  } else {
    removeItem(index);
    return;
  }
  updateBuy();
}

//  Remove Item
function removeItem(index) {
  buy.splice(index, 1);
  updateBuy();
}

//  NEW: ADD TO CART FUNCTION
function addToCart(index) {

  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let item = buy[index];

  const existing = cart.find(p =>
    p.id === item.id && p.size === item.size
  );

  if (existing) {
    existing.quantity += item.quantity;
  } else {
    cart.push(item);
  }

  localStorage.setItem("cart", JSON.stringify(cart));

  alert("Added to Cart ");
}

// Update Buy
function updateBuy() {
  localStorage.setItem("buy", JSON.stringify(buy));
  renderBuy();
}

//  Load
renderBuy();


// CHECKOUT (USE BUY NOT CART)
document.getElementById("checkout-form").addEventListener("submit", function(e) {
  e.preventDefault();

  if (buy.length === 0) {
    alert("No items to buy!");
    return;
  }

  let totalAmount = 0;
  buy.forEach(item => {
    totalAmount += item.price * item.quantity;
  });

  const order = {
    customer: {
      name: document.getElementById("name").value,
      phone: document.getElementById("phone").value,
      address: document.getElementById("address").value,
      payment: document.getElementById("payment").value
    },
    items: buy,
    total: totalAmount
  };

  localStorage.setItem("order", JSON.stringify(order));

  //  clear only buy
  localStorage.removeItem("buy");

  window.location.href = "order-success.html";
});
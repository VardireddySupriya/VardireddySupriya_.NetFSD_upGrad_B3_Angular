

document.addEventListener("DOMContentLoaded", () => {

  const container = document.getElementById("product-details");
  const similarContainer = document.getElementById("similar-products");

  const params = new URLSearchParams(window.location.search);
  const productId = params.get("id");

  fetch("../json/products.json")
    .then(res => res.json())
    .then(data => {

      const product = data.find(p => p.id == productId);

      if (!product) {
        container.innerHTML = "<h3>Product not found</h3>";
        return;
      }

      let selectedSize = null;

      //  Size buttons
      let sizeHTML = "";

      if (product.sizes && product.sizes.length > 0) {
        sizeHTML = `
          <div class="mt-3">
            <h6>Select Size:</h6>
            ${product.sizes.map(size => `
              <button class="btn btn-outline-dark btn-sm m-1 size-btn">
                ${size}
              </button>
            `).join("")}
            <p id="size-error" class="text-danger mt-2"></p>
          </div>
        `;
      }

      //  Render product
      container.innerHTML = `
        <div class="row">
          <div class="col-md-6">
            <img src="${product.image}" class="img-fluid rounded">
          </div>

          <div class="col-md-6">
            <h2>${product.name}</h2>
            <h4 class="text-success">₹${product.price}</h4>

            ${sizeHTML}

            <button class="btn btn-primary mt-3">Buy Now</button>
            <button class="btn btn-warning mt-3">Add to Cart</button>
          </div>
        </div>
      `;

      const error = document.getElementById("size-error");

      // Size selection
      document.querySelectorAll(".size-btn").forEach(btn => {
        btn.addEventListener("click", () => {
          document.querySelectorAll(".size-btn").forEach(b => b.classList.remove("active"));
          btn.classList.add("active");
          selectedSize = btn.innerText;

          if (error) error.innerText = "";
        });
      });

      //  ADD TO CART (NO CHANGE)
      document.querySelector(".btn-warning").addEventListener("click", () => {

        if (product.sizes && product.sizes.length > 0 && !selectedSize) {
          if (error) error.innerText = "Please select a size";
          return;
        }

        const item = {
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          size: selectedSize || "N/A",
          quantity: 1
        };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];

        const existing = cart.find(p =>
          p.id === item.id && p.size === item.size
        );

        if (existing) {
          existing.quantity += 1;
        } else {
          cart.push(item);
        }

        localStorage.setItem("cart", JSON.stringify(cart));

        window.location.href = "cart.html";
      });

      //  BUY NOW ( FIXED HERE)
      document.querySelector(".btn-primary").addEventListener("click", () => {

        if (product.sizes && product.sizes.length > 0 && !selectedSize) {
          if (error) error.innerText = "Please select a size";
          return;
        }

        const item = {
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          size: selectedSize || "N/A",
          quantity: 1
        };

        // REMOVE CART LOGIC COMPLETELY
        //  SAVE ONLY IN BUY

        let buy = JSON.parse(localStorage.getItem("buy")) || [];

        // optional: prevent duplicate
        const existing = buy.find(p =>
          p.id === item.id && p.size === item.size
        );

        if (existing) {
          existing.quantity += 1;
        } else {
          buy.push(item);
        }

        localStorage.setItem("buy", JSON.stringify(buy));

        window.location.href = "buy.html";
      });

      //  SIMILAR PRODUCTS (NO CHANGE)
      if (similarContainer) {
        const similarProducts = data.filter(p =>
          p.category === product.category && p.id != product.id
        );

        let similarHTML = "";

        similarProducts.forEach(p => {
          similarHTML += `
            <div class="col-md-3 mb-4">
              <div class="card shadow-sm">

                <img src="${p.image}" 
                     class="card-img-top"
                     style="height:200px; object-fit:cover; cursor:pointer;"
                     onclick="window.location.href='product-details.html?id=${p.id}'">

                <div class="card-body text-center">
                  <h6>${p.name}</h6>
                  <p class="text-success">₹${p.price}</p>
                </div>

              </div>
            </div>
          `;
        });

        similarContainer.innerHTML = similarHTML;
      }

    })
    .catch(err => console.error(err));

});
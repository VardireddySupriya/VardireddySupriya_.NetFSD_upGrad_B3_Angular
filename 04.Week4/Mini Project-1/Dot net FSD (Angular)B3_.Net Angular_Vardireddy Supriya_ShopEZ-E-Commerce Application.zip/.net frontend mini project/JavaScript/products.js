document.addEventListener("DOMContentLoaded", () => {

  const productList = document.getElementById("product-list");
  const title = document.getElementById("title");

  const params = new URLSearchParams(window.location.search);
  const selectedCategory = params.get("category");
  const selectedType = params.get("type"); // 🔥 optional (headphones, camera)

  fetch("../json/products.json")
    .then(res => res.json())
    .then(data => {

      let filteredProducts = data;

      //  Filter by category
      if (selectedCategory) {
        filteredProducts = filteredProducts.filter(p =>
          p.category.toLowerCase() === selectedCategory.toLowerCase()
        );
      }

      //  OPTIONAL: Filter by type (for headphones only etc.)
      if (selectedType) {
        filteredProducts = filteredProducts.filter(p =>
          p.name.toLowerCase().includes(selectedType.toLowerCase())
        );
      }

      // Title
      if (selectedCategory) {
        title.innerText = selectedCategory.toUpperCase() + " Products";
      }

      //  No products
      if (filteredProducts.length === 0) {
        productList.innerHTML = `
          <div class="text-center mt-5">
            <h4>No products found </h4>
          </div>
        `;
        return;
      }

      let output = "";

      filteredProducts.forEach(p => {
        output += `
          <div class="col-md-3 col-sm-6">

            <a href="product-details.html?id=${p.id}" 
               style="text-decoration:none; color:black;">

              <div class="card mb-4 shadow-sm h-100">

                <!--  IMAGE -->
                <img src="${p.image}" 
                     class="card-img-top"
                     style="height:200px; object-fit:cover;">

                <!--  DETAILS -->
                <div class="card-body text-center">
                  <h6>${p.name}</h6>
                  <p class="text-success fw-bold">₹${p.price}</p>
                </div>

              </div>

            </a>

          </div>
        `;
      });

      productList.innerHTML = output;

    })
    .catch(err => {
      console.error("Error:", err);
      productList.innerHTML = "<h4>Error loading products</h4>";
    });

});
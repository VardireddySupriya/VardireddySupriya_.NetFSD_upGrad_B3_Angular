
const container = document.getElementById("order-details");

const order = JSON.parse(localStorage.getItem("order"));

if (!order) {
  container.innerHTML = "<h4>No order found</h4>";
} else {

  const { name, phone, address } = order.customer || {};

  // VALIDATION CHECK
  if (!name || name.trim() === "") {
    container.innerHTML = "<h4 class='text-danger'>Name is missing in order</h4>";
    return;
  }

  if (!phone || phone.trim() === "") {
    container.innerHTML = "<h4 class='text-danger'>Mobile number is missing</h4>";
    return;
  }

  if (!address || address.trim() === "") {
    container.innerHTML = "<h4 class='text-danger'>Address is missing</h4>";
    return;
  }

  // DISPLAY ORDER DETAILS
  let output = `
    <h3>Order Details</h3>
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Phone:</strong> ${phone}</p>
    <p><strong>Address:</strong> ${address}</p>

    <h4 class="mt-4">Items:</h4>
    <ul>
  `;

  order.items.forEach(item => {
    output += `
      <li>
        ${item.name} - ₹${item.price} × ${item.quantity}
      </li>
    `;
  });

  output += `</ul>`;

  container.innerHTML = output;
}